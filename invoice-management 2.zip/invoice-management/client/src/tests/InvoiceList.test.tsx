import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import InvoiceList from '../components/InvoiceList';

global.fetch = jest.fn();

describe('InvoiceList', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  test('renders loading state', () => {
    render(<InvoiceList />);
    expect(screen.getByTestId('loading-message')).toBeInTheDocument();
  });

  test('renders error message when fetch fails', async () => {
    (fetch as jest.Mock).mockImplementationOnce(() =>
      Promise.reject(new Error('Failed to fetch data'))
    );

    render(<InvoiceList />);
    
    await waitFor(() => expect(screen.getByTestId('error-message')).toBeInTheDocument());
    expect(screen.getByTestId('error-message')).toHaveTextContent('Error fetching invoices: Failed to fetch data');
  });

  test('displays invoices after successful fetch', async () => {
    const mockInvoices = [
      {
        reference: 'INV-001',
        amount: 100,
        paid_amount: 0,
        status: 'UNPAID',
        created_at: '2024-09-01T00:00:00Z',
        due_date: '2024-09-15T00:00:00Z',
      },
    ];

    (fetch as jest.Mock).mockImplementationOnce(() =>
      Promise.resolve({
        ok: true,
        json: () => Promise.resolve(mockInvoices),
      })
    );

    render(<InvoiceList />);
    
    await waitFor(() => expect(screen.queryByTestId('loading-message')).not.toBeInTheDocument());

    expect(screen.getByTestId('invoice-reference-INV-001')).toBeInTheDocument();
    expect(screen.getByText('UNPAID')).toBeInTheDocument();
  });

  test('validates payment input correctly', async () => {
    const mockInvoices = [
      {
        reference: 'INV-001',
        amount: 100,
        paid_amount: 0,
        status: 'UNPAID',
        created_at: '2024-09-01T00:00:00Z',
        due_date: '2024-09-15T00:00:00Z',
      },
    ];

    (fetch as jest.Mock).mockImplementationOnce(() =>
      Promise.resolve({
        ok: true,
        json: () => Promise.resolve(mockInvoices),
      })
    );

    render(<InvoiceList />);

    await waitFor(() => expect(screen.queryByTestId('loading-message')).not.toBeInTheDocument());

    const paymentInput = screen.getByTestId('payment-input-INV-001');
    fireEvent.change(paymentInput, { target: { value: '200' } });
    expect(screen.getByTestId('error-message-INV-001')).toBeInTheDocument();
    expect(screen.getByTestId('error-message-INV-001')).toHaveTextContent('Invalid payment amount');

    fireEvent.change(paymentInput, { target: { value: '' } });
    expect(screen.queryByTestId('error-message-INV-001')).not.toBeInTheDocument();
  });

  test('shows alert when submitting invalid payment', async () => {
    const mockInvoices = [
      {
        reference: 'INV-001',
        amount: 100,
        paid_amount: 0,
        status: 'UNPAID',
        created_at: '2024-09-01T00:00:00Z',
        due_date: '2024-09-15T00:00:00Z',
      },
    ];

    (fetch as jest.Mock).mockImplementationOnce(() =>
      Promise.resolve({
        ok: true,
        json: () => Promise.resolve(mockInvoices),
      })
    );

    render(<InvoiceList />);

    await waitFor(() => expect(screen.queryByTestId('loading-message')).not.toBeInTheDocument());

    const paymentInput = screen.getByTestId('payment-input-INV-001');
    fireEvent.change(paymentInput, { target: { value: '0' } });

    window.alert = jest.fn();

    const submitButton = screen.getByTestId('submit-button-INV-001');
    fireEvent.click(submitButton);

    expect(window.alert).toHaveBeenCalledWith('Please enter a valid payment amount');
  });

  test('handles payment submission error', async () => {
    const mockInvoices = [
      {
        reference: 'INV-001',
        amount: 100,
        paid_amount: 0,
        status: 'UNPAID',
        created_at: '2024-09-01T00:00:00Z',
        due_date: '2024-09-15T00:00:00Z',
      },
    ];

    (fetch as jest.Mock).mockImplementationOnce(() =>
      Promise.resolve({
        ok: true,
        json: () => Promise.resolve(mockInvoices),
      })
    );

    render(<InvoiceList />);

    await waitFor(() => expect(screen.queryByTestId('loading-message')).not.toBeInTheDocument());

    const paymentInput = screen.getByTestId('payment-input-INV-001');
    fireEvent.change(paymentInput, { target: { value: '50' } });

    (fetch as jest.Mock).mockImplementationOnce(() =>
      Promise.reject(new Error('Failed to submit payment'))
    );

    const submitButton = screen.getByTestId('submit-button-INV-001');
    fireEvent.click(submitButton);

    await waitFor(() => expect(screen.getByTestId('error-message')).toBeInTheDocument());
    expect(screen.getByTestId('error-message')).toHaveTextContent('Failed to submit payment');
  });

  test('submits payment successfully and updates invoice', async () => {
    const mockInvoices = [
      {
        reference: 'INV-001',
        amount: 100,
        paid_amount: 0,
        status: 'UNPAID',
        created_at: '2024-09-01T00:00:00Z',
        due_date: '2024-09-15T00:00:00Z',
      },
    ];

    (fetch as jest.Mock).mockImplementationOnce(() =>
      Promise.resolve({
        ok: true,
        json: () => Promise.resolve(mockInvoices),
      })
    );

    render(<InvoiceList />);

    await waitFor(() => expect(screen.queryByTestId('loading-message')).not.toBeInTheDocument());

    const paymentInput = screen.getByTestId('payment-input-INV-001');
    fireEvent.change(paymentInput, { target: { value: '50' } });

    (fetch as jest.Mock).mockImplementationOnce(() =>
      Promise.resolve({
        ok: true,
        json: () => Promise.resolve({ message: 'Payment successful', newStatus: 'PARTIALLY PAID' }),
      })
    );

    const submitButton = screen.getByTestId('submit-button-INV-001');
    fireEvent.click(submitButton);

    await waitFor(() => {
      expect(screen.getByText('PARTIALLY PAID')).toBeInTheDocument();
      expect(screen.getByTestId('invoice-reference-INV-001')).toBeInTheDocument();
      expect(screen.getByText('50')).toBeInTheDocument();
    });
  });
});

describe('InvoiceList Error Handling', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  test('handles error when fetching invoices fails', async () => {
    (fetch as jest.Mock).mockImplementationOnce(() =>
      Promise.resolve({
        ok: false,
      })
    );

    render(<InvoiceList />);

    await waitFor(() => expect(screen.getByTestId('error-message')).toBeInTheDocument());
    expect(screen.getByTestId('error-message')).toHaveTextContent('Error fetching invoices: Failed to fetch data');
  });

  test('handles error when submitting payment fails', async () => {
    const mockInvoices = [
      {
        reference: 'INV-001',
        amount: 100,
        paid_amount: 0,
        status: 'UNPAID',
        created_at: '2024-09-01T00:00:00Z',
        due_date: '2024-09-15T00:00:00Z',
      },
    ];

    (fetch as jest.Mock).mockImplementationOnce(() =>
      Promise.resolve({
        ok: true,
        json: () => Promise.resolve(mockInvoices),
      })
    );

    render(<InvoiceList />);

    await waitFor(() => expect(screen.queryByTestId('loading-message')).not.toBeInTheDocument());

    const paymentInput = screen.getByTestId('payment-input-INV-001');
    fireEvent.change(paymentInput, { target: { value: '50' } });

    (fetch as jest.Mock).mockImplementationOnce(() =>
      Promise.resolve({
        ok: false,
      })
    );

    const submitButton = screen.getByTestId('submit-button-INV-001');
    fireEvent.click(submitButton);

    await waitFor(() => expect(screen.getByTestId('error-message')).toBeInTheDocument());
    expect(screen.getByTestId('error-message')).toHaveTextContent('Failed to submit payment');
  });
});
