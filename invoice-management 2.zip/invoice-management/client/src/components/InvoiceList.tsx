import React, { useState, useEffect } from 'react';
import '../styles/InvoiceList.css'; 

interface Invoice {
  reference: string;
  amount: number;
  paid_amount: number;
  status: string;
  created_at: string;
  due_date: string;
}

const InvoiceList: React.FC = () => {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [paymentAmount, setPaymentAmount] = useState<{ [key: string]: number | string }>({});
  const [isPaymentValid, setIsPaymentValid] = useState<{ [key: string]: boolean }>({});
  const [hasUserInteracted, setHasUserInteracted] = useState<{ [key: string]: boolean }>({});
  const [loading, setLoading] = useState<boolean>(true); // Loading state
  const [error, setError] = useState<string | null>(null); // Error state

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/invoices');
        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }
        const data = await response.json();
        setInvoices(data);
        setLoading(false);
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred';
        setError(errorMessage);
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const handlePaymentChange = (reference: string, amount: number) => {
    const invoice = invoices.find(inv => inv.reference === reference);
    if (invoice) {
      const remainingAmount = invoice.amount - invoice.paid_amount;
      setHasUserInteracted({ ...hasUserInteracted, [reference]: true });

      if (isNaN(amount)) {
        setIsPaymentValid({ ...isPaymentValid, [reference]: true });
      } 
     
      else if (amount > remainingAmount || amount < 0) {
        setIsPaymentValid({ ...isPaymentValid, [reference]: false });
      } else {
        setIsPaymentValid({ ...isPaymentValid, [reference]: true });
      }

      setPaymentAmount({
        ...paymentAmount,
        [reference]: isNaN(amount) ? '' : amount,
      });
    }
  };

  const handleSubmitPayment = async (invoice: Invoice) => {
    const payment = parseFloat(paymentAmount[invoice.reference] as string) || 0; // Convert to number or default to 0
  
    if (payment <= 0 || !isPaymentValid[invoice.reference]) {
      alert('Please enter a valid payment amount');
      return;
    }
  
    try {
      const response = await fetch('http://localhost:5000/api/pay', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          reference: invoice.reference,
          paymentAmount: payment,
        }),
      });
  
      if (!response.ok) {
        throw new Error('Failed to submit payment');
      }
  
      const result = await response.json();
      console.log(result.message);
  
      setInvoices((prevInvoices) =>
        prevInvoices.map((inv) =>
          inv.reference === invoice.reference
            ? { 
                ...inv, 
                paid_amount: inv.paid_amount + payment, 
                status: result.newStatus
              }
            : inv
        )
      );
   
      setPaymentAmount({
        ...paymentAmount,
        [invoice.reference]: '',
      });
      setIsPaymentValid({ ...isPaymentValid, [invoice.reference]: true });
      setHasUserInteracted({ ...hasUserInteracted, [invoice.reference]: false });
  
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred';
      setError(errorMessage);
    }
  };

  if (loading) {
    return <div data-testid="loading-message">Loading invoices...</div>;
  }
  const LoadingState = () => <div data-testid="loading-message">Loading invoices...</div>;

  if (error) {
    return <div data-testid="error-message">Error fetching invoices: {error}</div>;
  }

  return (
    <div className="invoice-list">
      <h1>Invoice List</h1>
      <table>
        <thead>
          <tr>
            <th>Reference</th>
            <th>Amount</th>
            <th>Paid Amount</th>
            <th>Status</th>
            <th>Created At</th>
            <th>Due Date</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {invoices.map((invoice) => (
            <tr key={invoice.reference}>
              <td data-testid={`invoice-reference-${invoice.reference}`}>{invoice.reference}</td>
              <td>{invoice.amount}</td>
              <td>{invoice.paid_amount}</td>
              <td>{invoice.status}</td>
              <td>{new Date(invoice.created_at).toLocaleDateString()}</td>
              <td>{new Date(invoice.due_date).toLocaleDateString()}</td>
              <td>
                {invoice.status !== 'PAID' && (
                  <div className="payment-action">
                    <input
                      type="number"
                      data-testid={`payment-input-${invoice.reference}`}
                      value={paymentAmount[invoice.reference] || ''}
                      onChange={(e) => handlePaymentChange(invoice.reference, parseFloat(e.target.value))}
                      placeholder="Enter payment"
                      min="0"
                      max={invoice.amount - invoice.paid_amount}
                    />
                    {hasUserInteracted[invoice.reference] && !isPaymentValid[invoice.reference] && paymentAmount[invoice.reference] !== '' && (
                      <small className="error-message" data-testid={`error-message-${invoice.reference}`}>
                        Invalid payment amount
                      </small>
                    )}
                    <button 
                      data-testid={`submit-button-${invoice.reference}`}
                      onClick={() => handleSubmitPayment(invoice)} 
                      disabled={!isPaymentValid[invoice.reference] || paymentAmount[invoice.reference] === ''}
                    >
                      Submit
                    </button>
                  </div>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default InvoiceList;
