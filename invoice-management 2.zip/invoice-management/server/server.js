const express = require('express');
const cors = require('cors');
const mysql = require('mysql2');

const app = express();
const port = 5000;

app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
  host: 'localhost',       // Ensure this is correct
  user: 'user',            // Your MySQL username
  password: 'password',    // Your MySQL password
  database: 'invoices',    // Your database name
  port: 3306               // Ensure this matches your Docker mapping
});

db.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
  } else {
    console.log('Connected to MySQL');
  }
});

app.get('/api/invoices', (req, res) => {
  const query = 'SELECT * FROM invoices';
  db.query(query, (err, results) => {
    if (err) {
      console.error('Error fetching invoices:', err);
      res.status(500).json({ error: 'Failed to fetch invoices' });
    } else {
      res.json(results);
    }
  });
});

app.post('/api/pay', (req, res) => {
  const { reference, paymentAmount } = req.body;

  if (!reference || paymentAmount == null) {
    return res.status(400).json({ error: 'Missing reference or paymentAmount' });
  }

});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
