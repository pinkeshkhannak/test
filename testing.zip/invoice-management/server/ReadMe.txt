docker-compose down
docker-compose up -d



docker exec -it invoice_db mysql -u root -p

USE invoices;
GRANT ALL PRIVILEGES ON invoices.* TO 'user'@'%' IDENTIFIED BY 'password';
FLUSH PRIVILEGES;

EXIT;