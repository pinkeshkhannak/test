import React from 'react';
import './App.css';
import InvoiceList from './components/InvoiceList';

function App() {
  const greeting: string = "hey sHEAK"
  return (
    <div className="App">
      <InvoiceList/>
    </div>
  );
}

export default App;
